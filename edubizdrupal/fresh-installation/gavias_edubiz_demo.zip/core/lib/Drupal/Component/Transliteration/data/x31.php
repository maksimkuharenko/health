<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => NULL, NULL, NULL, NULL, NULL, 'b', 'p', 'm1', 'f', 'd', 't', 'n1', 'l', 'g', 'k', 'h',
  0x10 => 'j', 'q', 'x', 'zhi1', 'chi1', 'shi1', 'ri1', 'zi1', 'ci1', 'si1', 'a1', 'o1', 'e1', 'eh1', 'ai1', 'ei1',
  0x20 => 'ao1', 'ou1', 'an1', 'en1', 'ang1', 'eng1', 'er1', 'yi1', 'wu1', 'yu1', 'V', 'NG', 'GN', NULL, NULL, NULL,
  0x30 => NULL, 'g', 'kk', 'gs', 'n', 'nj', 'nh', 'd', 'tt', 'l', 'lg', 'lm', 'lb', 'ls', 'lt', 'lp',
  0x40 => 'rh', 'm', 'b', 'pp', 'bs', 's', 'ss', '', 'j', 'jj', 'ch', 'k', 't', 'p', 'h', 'a',
  0x50 => 'ae', 'ya', 'yae', 'eo', 'e', 'yeo', 'ye', 'o', 'wa', 'wae', 'oe', 'yo', 'u', 'wo', 'we', 'wi',
  0x60 => 'yu', 'eu', 'ui', 'i', '', 'nn', 'nd', 'ns', 'nZ', 'lgs', 'ld', 'lbs', 'lZ', 'lQ', 'mb', 'ms',
  0x70 => 'mZ', 'mN', 'bg', '', 'bsg', 'bst', 'bj', 'bt', 'bN', 'bbN', 'sg', 'sn', 'sd', 'sb', 'sj', 'Z',
  0x80 => '', 'N', 'Ns', 'NZ', 'pN', 'hh', 'Q', 'yo-ya', 'yo-yae', 'yo-i', 'yu-yeo', 'yu-ye', 'yu-i', 'U', 'U-i', NULL,
  0x90 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xA0 => 'BU', 'ZI', 'JI', 'GU', 'EE', 'ENN', 'OO', 'ONN', 'IR', 'ANN', 'INN', 'UNN', 'IM', 'NGG', 'AINN', 'AUNN',
  0xB0 => 'AM', 'OM', 'ONG', 'INNN', 'P', 'T', 'K', 'H', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xC0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xD0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xE0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xF0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
];
